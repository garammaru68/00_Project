//
// Copyright 2010 Autodesk, Inc.  All rights reserved.
//
// Use of this software is subject to the terms of the Autodesk license
// agreement provided at the time of installation or download, or which 
// otherwise accompanies this software in either electronic or hard copy form.   
//
//

#pragma once

namespace MaxSDK { namespace Graphics {

	/** Enum type for all visual styles of nitrous viewport
	*/
	enum VisualStyle
	{
		/** The realistic visual style
		*/
		VisualStyleRealistic = 0,
		/** The shaded visual style
		*/
		VisualStyleShaded,
		/** The facet visual style
		*/
		VisualStyleFacets,
		/** The consistent color visual style
		*/
		VisualStyleConsistentColor,
		/** The hidden line visual style
		*/
		VisualStyleHiddenLine,
		/** The wireframe visual style
		*/
		VisualStyleWireframe,
		/** The bounding box visual style
		*/
		VisualStyleBoundingBox,
		/** The ink visual style for NPR
		*/
		VisualStyleInk,
		/** The color ink visual style of NPR
		*/
		VisualStyleColorInk,
		/** The acrylic stylized visual style
		*/
		VisualStyleAcrylic,
		/** The tech stylized visual style
		*/
		VisualStyleTech,
		/** The graphite stylized visual style
		*/
		VisualStyleGraphite,
		/** The color pencil stylized visual style
		*/
		VisualStyleColorPencil,
		/** The pastel stylized visual style
		*/
		VisualStylePastel,
		/** The clay visual style
		*/
		VisualStyleClay,
        /** The Model Assist visual style from Max 2016 (smoothing using invisible edge and not smooth only groups) MAXX-34246
        */
        VisualStyleModelAssist,
		/** The count of all visual styles
		*/
		VisualStyleCount,
	};

	/** Enum type for all presets of nitrous viewport
	*/
	enum ViewportPreset {
		/** The quality preset.
		*/
		ViewportPresetQuality,
		/** The standard preset.
		*/
		ViewportPresetStandard,
		/** The performance preset.
		*/
		ViewportPresetPerformance,
		/** The DX mode preset.
		*/
		ViewportPresetDXMode,
		/** The user customize preset.
		*/
		ViewportPresetCustomize,
		/** The count of all presets
		*/
		ViewportPresetCount
	};

} } // end namespace

