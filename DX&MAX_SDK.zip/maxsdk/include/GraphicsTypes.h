//
// Copyright 2010 Autodesk, Inc.  All rights reserved. 
//
//  Use of this software is subject to the terms of the Autodesk license 
//  agreement provided at the time of installation or download, or which 
//  otherwise accompanies this software in either electronic or hard copy form.
#pragma once

#include <WTypes.h>

typedef BOOL	(*HitFunc)(int, int, void *);
typedef void (*GFX_ESCAPE_FN)(void *);

/** Camera Types */
enum CameraType
{
	PERSP_CAM,			//!< Perspective view camera type.
	ORTHO_CAM			//!< Orthographic projection camera type. 
};

/** Color types (used by setColor) */
enum ColorType
{
	LINE_COLOR,			//!< Line drawing color.
	FILL_COLOR,			//!< Polygon fill color.
	TEXT_COLOR,			//!< Text drawing color.
	CLEAR_COLOR,			//!< The color that the viewport is cleared to when you call clearScreen()
	GRADIENT_BOTTOM_COLOR,		//!< The bottom color used for gradient viewport background
	GRADIENT_TOP_COLOR,		//!< The top color used for gradient viewport background
	COLOR_TYPE_COUNT		//!< the count of the color types
};

/** Marker types. \see GraphicsWindow::hMarker() */
enum MarkerType
{
	POINT_MRKR,			//!< A single pixel on the display.
	HOLLOW_BOX_MRKR,	//!< A small box centered on the point.
	PLUS_SIGN_MRKR,		//!< A plug sign (+) at the point.
	ASTERISK_MRKR,		//!< An asterisk (*) at the point.
	X_MRKR,				//!< An X at the point.
	BIG_BOX_MRKR,		//!< A large box centered on the point.
	CIRCLE_MRKR,		//!< A circle at the point.
	TRIANGLE_MRKR,		//!< A triangle centered on the point.
	DIAMOND_MRKR,		//!< A diamond centered on the point.
	SM_HOLLOW_BOX_MRKR,	//!< A hollow box at the point.
	SM_CIRCLE_MRKR,		//!< A small circle at the point.
	SM_TRIANGLE_MRKR,	//!< A small triangle centered on the point.
	SM_DIAMOND_MRKR,	//!< A small diamond centered on the point.
	DOT_MRKR,			//!< A large dot.
	SM_DOT_MRKR,		//!< A smaller dot.
	BOX2_MRKR,
	BOX3_MRKR,
	BOX4_MRKR,
	BOX5_MRKR,
	BOX6_MRKR,
	BOX7_MRKR,
	DOT2_MRKR,
	DOT3_MRKR,
	DOT4_MRKR,
	DOT5_MRKR,
	DOT6_MRKR,
	DOT7_MRKR
};

/** Facing type */
enum FacingType
{
	kFrontFacing,
	kSideFacing,
	kBackFacing
};

// forward declaration
class ID3D9GraphicsWindow;
typedef ID3D9GraphicsWindow ID3DGraphicsWindow;